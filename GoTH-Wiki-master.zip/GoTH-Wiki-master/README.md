# GoTH-Wiki
Guardians of the Horde wiki. Duh

Uses [Mkdocs](http://www.mkdocs.org/), installable via pip.

Use `mkdocs serve` while in the wiki directory to test local work.
