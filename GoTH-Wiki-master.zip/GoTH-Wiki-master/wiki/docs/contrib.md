# Guardians of the Horde Incursion Wiki

## Contributing to the wiki

If you are interested in helping contribute to the wiki, speak to Telltak Laellithor either in game or via discord. The wiki is built using mkdocs so anyone with even a little markdown and git knowledge can help.
