# Welcome to the Guardians of the Horde Incursion Wiki

The Guardians of the Horde and friendsTM incursion sig is made of only the dankest dudes making isk when CCP gives us an incursion.


If you are interested in joining, please join [Discord](https://discord.gg/A2kMpSf) and follow the preauth instructions.


A list of fittings are included in [Fittings](fittings.md), though remember these are not exhaustive. We also list our general requirements for ships.


Nothing on this wiki is specifically exhaustive, but please use common sense when looking at information.

Please look at [Support](support.md) for common issues and information about how the auth system works
