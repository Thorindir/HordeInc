# Guardians of the Horde Incursion Fittings

## T3Cs

Please note the subsystems in cargo, feel free to move them to the subsystem cargo. CCPlz

As with all T3C fits, remember that CCP and fitting agents are bad at importing T3Cs. If you have issues, remove the subystems from the fitting before copying

Be aware that no specific T3C fit is preferred. Fly whatever you have the best skills for and feel free to fill your cargo with extra ammo.

* [Logi](t3logi.md)
* [Loki](loki.md)
* [Tengu](tengu.md)
