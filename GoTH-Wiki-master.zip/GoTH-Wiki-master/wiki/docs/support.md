# Guardians of the Horde Incursion

## Joining the server

When you first join the [Discord](https://discord.gg/A2kMpSf) server, you will see two channels: Preauth and support.

Please follow the instructions in Preauth to gain access to the rest of the discord server. If you have issues authing, please ping Callum Lul or Telltak Laellithor and they will help you.

### Common issues authing

* Skynet keeps telling you to join the server first: Check what discord account you are signed into on your browser. Skynet uses your discord ID to track your accounts.

## Access to restricted channels

Certain channels, such as capitals and T3Cs have restricted access. In order to gain access to any channels like these, you must have both the required skills and own at least one ship of that type on one of the characters you have authed.

If you don't see these channels within 4 hours of authing a toon with these assets and skills, please ping Callum Lul or Telltak Laellithor and they will help you.
